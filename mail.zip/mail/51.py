#!/usr/bin/python

import json
import requests
kulbil= {"kadi":"karaelmas", "sifre":"teknoyz449"}
jsonkulbil=json.dumps(kulbil,sort_keys=True)
#response = requests.get("http://212.68.57.202:52196/api/frame_listesi")
#todos = json.loads(response.text)
#print(type(kulbil))
print(type(jsonkulbil))
print(jsonkulbil)
jresimlistesi={
"frame_id": 1,
"video": "test.mp4",
"frame_link": "1.jpg"
},
{
"frame_id": 2,
"video": "test.mp4",
"frame_link": "2.jpg"
},
{
"frame_id": 3,
"video": "test.mp4",
"frame_link": "3.jpg"
}
jresimlistesi=json.dumps(jresimlistesi)
data = json.loads(jresimlistesi,parse_int=int,parse_float=list)
print('User count:', len(data))
for item in data:
    print('frame_id', item['frame_id'])
    print('video', item['video'])
    print('frame_link', item['frame_link'])
print(data)

#print('frame id: {:d}'.format(data["frame_id"]))
#print('video: {}'.format(data["video"]))
#print('link: {}'.format(data["frame_link"]))

