#!/usr/bin/python


import json 
import urllib.request

#siniflar

with open("gir/response2.json") as json_file:
 dosyalistesi=json.load(json_file)
dosyasayisi= len(dosyalistesi)-1
hedefklasor='cik/'
kaynakklasor='gir/'
for item in dosyalistesi:
 frame_id=item['frame_id']
 video=item['video']
 frame_link=item['frame_link']
 secilendosya=frame_link
 dosyaAdi = secilendosya.replace("http://212.68.57.202/images/", "")
 #dosyaAdi = dosyaAdi.replace("B23072019_V1_K1/", "")
 #dosyaAdi = dosyaAdi.replace("T190619_V4_K1/", "")
 resimadi = dosyaAdi.replace(".jpg", "")
 urllib.request.urlretrieve(frame_link, kaynakklasor+dosyaAdi)
 secilendosya=kaynakklasor+dosyaAdi
 #print(dosyaAdi)
 #print(resimadi)
 dosyasayisi=dosyasayisi-1


