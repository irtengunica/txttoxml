#!/usr/bin/python

import json

class Person(object):
    
    def __init__(self, tur, x1, y1, x2, y2):
    
        self.tur = tur
        self.x1 = x1
        self.y1 = x1
        self.x2 = x2
        self.y2 = y2
        
    def toJson(self):
        '''
        Serialize the object custom object
        '''
        return json.dumps(self, default=lambda o: o.__dict__, 
                sort_keys=True, indent=4)            

p1 = Person("arac", 23, 34, 456, 345)
p2 = [{"frame_id": 568,"objeler": p1}]

people = []
people.append(json.loads(p1.toJson()))
#people.append(json.loads(p2.toJson()))

json_data = json.dumps(people)

print(repr(json_data))

