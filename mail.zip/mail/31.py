#!/usr/bin/python

import json
class Employee(object):
    def __init__(self, frame_id, tur, x1, y1, x2, y2):
        self.frame_id = frame_id
        self.objeler =""
        self.tur = tur
        self.x1 = x1
        self.y1 = y1
        self.x2 = x2
        self.y2 = y2

    # This method can return a python dict object by the class instance.
    # And the dict object can be serialized to JSON.
    def employee2dict(self, employee):
        return {
            'frame_id': employee.frame_id,
            'objeler': [
		{
			'tur': employee.tur,
			'x1': employee.x1,
			'y1': employee.y1,
			'x2': employee.x2,
			'y2': employee.y2
		}
			]
        }

employee = Employee(568,"arac", 23, 34, 456, 345)
print(json.dumps(employee, default=employee.employee2dict))
