#!/usr/bin/python

import json
import requests
kulbil= {"kadi":"karaelmas", "sifre":"teknoyz449"}
with open("response.json") as json_file:
 data=json.load(json_file)

for item in data:
    print('frame_id', item['frame_id'])
    print('video', item['video'])
    print('frame_link', item['frame_link'])
print('User count:', len(data))

#print('frame id: {:d}'.format(data["frame_id"]))
#print('video: {}'.format(data["video"]))
#print('link: {}'.format(data["frame_link"]))

