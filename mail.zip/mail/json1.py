#!/usr/bin/python
import argparse
import sys
import glob
import cv2
import os
import numpy as np
import cv2
import json 
jframeid='frameid'
jobjeler='objeler'
jtur='tur'
jx1='x1'
jy1='y1'
jx2='x2'
jy2='y2'
vframeid=0
vobjeler=''
vtur=[]
vx1=list()
vy1=list()
vx2=list()
vy2=list()
sonveri='}'
objeveri=''
baslikveri=''
say=1
#z=''
for i in range(1,3):
 vtur[say]='yaya'
 vx1[say]=233
 vy1[say]=133
 vx2[say]=234
 vy2[say]=334
 say+=1
 k|={jtur: vtur[say],jx1: vx1[say],jy1: vy1[say],jx2: vx2[say],jy2: vy2[say]}
x = {
  jframeid: say,
  jobjeler: [ k ]
}

# convert into JSON:
y = json.dumps(x)

# the result is a JSON string:
print(y)

donustur2=json.dumps({jframeid: 568, jobjeler:[{jtur: "yaya",jx1: 235,jy1: 26,jx2: 312,jy2: 98},]}, sort_keys=True)
print donustur2
