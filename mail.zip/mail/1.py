#!/usr/bin/python

import json

a_dict = {'deneme2': 'deneme12'}

with open('new.json') as f:
    data = json.load(f)

data.append(a_dict)

with open('test.json', 'w') as f:
    json.dump(data, f)
