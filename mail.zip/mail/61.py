#!/usr/bin/python

import json
import requests
##sisteme giris
kulbil = {"kadi" : "karaelmas", "sifre" : "teknoyz449"}
jkulbil = json.dumps(kulbil, sort_keys=True)
print(jkulbil)
girisURL="http://212.68.57.202:52196/api/giris/"
r = requests.post(url = girisURL, data = jkulbil) 
# extracting response text  
pastebin_url = r.text 
print("The pastebin URL is:%s"%pastebin_url) 
##sisteme giris
###sistemden bilgi cekme
framelistURL="ttp://212.68.57.202:52196/api/frame_listesi"
#hres = urllib.request.urlopen(framelistURL)
#jresimlistesi = json.loads(hres.read().decode("utf-8"))
##calismazsa diger yol
response = requests.get(url = framelistURL, params = jkulbil)
jresimlistesi = json.loads(response.text)
##calismazsa diger yol
print(jresimlistesi)
###sistemden bilgi cekme

##cevapgonder
cevap = {"kadi" : "karaelmas", "sifre" : "teknoyz449"}
jcevap = json.dumps(cevap, sort_keys=True)
print(jcevap)
cevapURL="http://212.68.57.202:52196/api/cevap_gonder"
response = requests.get(url = cevapURL, params = jcevap)
# extracting response text  
pastebin_url = r 
print("The pastebin URL is:%s"%pastebin_url) 
##cevapgonder
