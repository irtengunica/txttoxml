#!/usr/bin/python

import json
class Cerceve(object):
    def __init__(self, frame_id):
        self.frame_id = frame_id
        self.objeler =""


    # This method can return a python dict object by the class instance.
    # And the dict object can be serialized to JSON.
    def cerceve2dict(self, cerceveadi):
        return {
            'frame_id': cerceveadi.frame_id,
            'objeler':	altcerceve
        }
class AltCerceve(object):
    
    def __init__(self, tur, x1, y1, x2, y2):
    
        self.tur = tur
        self.x1 = x1
        self.y1 = y1
        self.x2 = x2
        self.y2 = y2
        
    def toJson(self):
        '''
        Serialize the object custom object
        '''
        return json.dumps(self, default=lambda o: o.__dict__, 
                sort_keys=True, indent=4)            

p1 = AltCerceve("arac", 23, 34, 456, 345)
altcerceve = []
altcerceve.append(json.loads(p1.toJson()))
altcerceve.append(json.loads(p1.toJson()))
cerceveadi = Cerceve(568)
jsondata=json.dumps(cerceveadi, default=cerceveadi.cerceve2dict)
thgs=open('test1.json', 'w')
thgs.write(jsondata)

