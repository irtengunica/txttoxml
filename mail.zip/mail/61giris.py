#!/usr/bin/python
import json
import requests
s = requests.Session()
url = 'http://212.68.57.202:52196/api/giris'
data = {"kadi" : "karaelmas","sifre" : "teknoyz449"}
r = s.post(url, json=data)
print(r.status_code)
get_url = 'http://212.68.57.202:52196/api/frame_listesi'
p = s.get(get_url)
print(p.status_code)
