#!/usr/bin/python
#
# Copyright (c) 2019, NVIDIA CORPORATION. All rights reserved.
#
# Permission is hereby granted, free of charge, to any person obtaining a
# copy of this software and associated documentation files (the "Software"),
# to deal in the Software without restriction, including without limitation
# the rights to use, copy, modify, merge, publish, distribute, sublicense,
# and/or sell copies of the Software, and to permit persons to whom the
# Software is furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
# DEALINGS IN THE SOFTWARE.
#

import jetson.inference
import jetson.utils

import argparse
import sys
import glob
import os
import numpy as np
import cv2
import json 

#siniflar
class Cerceve(object):
    def __init__(self, frame_id):
        self.frame_id = frame_id
        self.objeler =""


    # This method can return a python dict object by the class instance.
    # And the dict object can be serialized to JSON.
    def cerceve2dict(self, cerceveadi):
        return {
            'frame_id': cerceveadi.frame_id,
            'objeler':	altcerceve
        }
class AltCerceve(object):
    
    def __init__(self, tur, x1, y1, x2, y2):
    
        self.tur = tur
        self.x1 = x1
        self.y1 = y1
        self.x2 = x2
        self.y2 = y2
        
    def toJson(self):
        '''
        Serialize the object custom object
        '''
        return json.dumps(self, default=lambda o: o.__dict__, 
                sort_keys=True, indent=4)   
#siniflar

# parse the command line
parser = argparse.ArgumentParser(description="Locate objects in an image using an object detection DNN.", 
						   formatter_class=argparse.RawTextHelpFormatter, epilog=jetson.inference.detectNet.Usage())

parser.add_argument("file_in", type=str, help="filename of the input image to process")
parser.add_argument("file_out", type=str, default=None, nargs='?', help="filename of the output image to save")
parser.add_argument("--network", type=str, default="pednet", help="pre-trained model to load, see below for options")
parser.add_argument("--threshold", type=float, default=0.5, help="minimum detection threshold to use")
parser.add_argument("--profile", type=bool, default=False, help="enable performance profiling and multiple runs of the model")
parser.add_argument("--runs", type=int, default=15, help="if profiling is enabling, the number of iterations to run")

try:
	opt, argv = parser.parse_known_args()
except:
	print("")
	parser.print_help()
	sys.exit(0)
#engin
kaynakklasor='gir/'
hedefklasor='cik/'
dosyalistesi=list(glob.glob(kaynakklasor+'*.jpg'))
dosyasayisi=len(dosyalistesi)-1
for file in dosyalistesi:
#for file in range(1,2):
 #print(file)
 #print(dosyasayisi)
 secilendosya=dosyalistesi[dosyasayisi]
 dosyaAdi = secilendosya.replace(kaynakklasor, "")
 resimadi = dosyaAdi.replace(".jpg", "")
 #print(dosyaAdi)
 #print(resimadi)
 dosyasayisi=dosyasayisi-1
 img = cv2.imread(secilendosya)
 height, width, channels = img.shape
 #print(height, width, channels)
#engin

# load an image (into shared CPU/GPU memory)
 opt.file_in=str(secilendosya)
 opt.file_out=str(hedefklasor+dosyaAdi)
 img, width, height = jetson.utils.loadImageRGBA(opt.file_in)

# load the object detection network
 net = jetson.inference.detectNet(opt.network, argv, opt.threshold)

# enable model profiling
 if opt.profile is True:
  net.EnableLayerProfiler()
 else:
  opt.runs = 1

# run model inference
 for i in range(opt.runs):
  if opt.runs > 1:
   print("\n/////////////////////////////////////\n// RUN {:d}\n/////////////////////////////////////".format(i))
	
	# detect objects in the image (with overlay)
  detections = net.Detect(img, width, height)

	# print the detections
  print("{:d} Nesne tespiti yapilmistir.".format(len(detections)))
  altcerceve = []
  for detection in detections:
   #print(detection)
   sinif=detection.ClassID
   if sinif==0:
    ssinif='arac'
   else:
    ssinif='yaya'
   x1 = str(np.uint8(detection.Left))
   y1 = str(np.uint8(detection.Top))
   x2 = str(np.uint8(detection.Right))
   y2 = str(np.uint8(detection.Bottom))
   #satir1=str(detection)
   #Type = satir1.split()
   #x1 = Type[10]
   #y1 = Type[13]
   #x2 = Type[16]
   #y2 = Type[19]
   #print('mmmmm')
   #print(ssinif,x1,y1,x2,y2,dosyaAdi, width, height)
   p1 = AltCerceve(ssinif,x1,y1,x2,y2)
   altcerceve.append(json.loads(p1.toJson()))
   #print('mmmmm')

	# wait for GPU to complete work
  jetson.utils.cudaDeviceSynchronize()

	# print out timing info
  net.PrintProfilerTimes()

# save the output image with the bounding box overlays
 cerceveadi = Cerceve(dosyasayisi)
 #print(json.dumps(cerceveadi, default=cerceveadi.cerceve2dict))
 
 if os.path.isfile("gir/test.json"):
   with open('gir/test.json', 'a') as f:
    f.write(json.dumps(cerceveadi, default=cerceveadi.cerceve2dict))
    f.write('\n ')
 else:
   with open('gir/test.json', 'w') as f:
    f.write(json.dumps(cerceveadi, default=cerceveadi.cerceve2dict))
    f.write('\n ')
 if opt.file_out is not None:
  jetson.utils.saveImageRGBA(opt.file_out, img, width, height)


